//Define an angular module for our app
var app = angular.module('taskManager', []);